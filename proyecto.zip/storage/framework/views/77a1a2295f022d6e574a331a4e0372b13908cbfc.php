<?php
  use Illuminate\Support\Facades\DB;
  use Illuminate\Support\Facades\Auth;
   
  $anio = DB::table('cursos')->select('anio')->distinct()->get();
  $curso =DB::table('tipo_curso')->select('tipo_curso.descripcion', 'tipo_curso.id as id')->get();
  
?>
<!-- Button trigger modal -->
<!-- Modal -->
<form action="<?php echo e(route('listarestudo')); ?>" method="POST">
 <?php echo csrf_field(); ?>
<div class="modal fade alerta" id="exampleModalListaB" tabindex="-1" aria-labelledby="exampleModalListaBLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalListaBLabel">Periodo Académico</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!--periodo academico-->
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                <label for="exampleFormControlSelect1">Curso</label>
                <select class="form-control" id="cursoba" name="cursoba">
                <?php $__currentLoopData = $curso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($cur->id)): ?>
                    <option value="<?php echo e($cur->id); ?>"><?php echo e($cur->descripcion); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div> 
            </div>
        </div>
        <div class="row">
        <div class="col-6">
          <div class="form-group">
            <label for="exampleFormControlSelect1">Año</label>
            <select class="form-control" id="anio" name="anio">
              <?php $__currentLoopData = $anio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($a->anio)): ?>
                  <option value="<?php echo e($a->anio); ?>"><?php echo e($a->anio); ?></option>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div> 
        </div>
        <div class="col-6">
        <div class="form-group">
          <label for="exampleFormControlSelect1">Periodo</label>
          <select class="form-control" id="periodo" name="periodo">
             <option value="A">A</option>
             <option value="B">B</option>
          </select>
        </div>
       </div>
       </div>
        <!-- end per acdemico-->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Salir</button>
        <button type="submit" class="btn btn-primary">Ver</button>
      </div>
    </div>
  </div>
</div>
</form>
<style>
  .modal-backdrop {
  z-index: -1;
  }
</style><?php /**PATH C:\xampp\htdocs\INEAC\resources\views/docente/listadoEstu.blade.php ENDPATH**/ ?>