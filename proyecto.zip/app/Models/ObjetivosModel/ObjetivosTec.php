<?php

namespace App\Models\ObjetivosModel;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ObjetivosTec extends Model
{
    protected $table = 'objetivostec';
    protected $primaryKey = "id";//tiene que hacer referencia a la llave primaria  
}
