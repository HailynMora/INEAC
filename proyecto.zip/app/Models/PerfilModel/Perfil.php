<?php

namespace App\Models\PerfilModel;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Perfil extends Model
{
    protected $table = 'perfil_docente';
    protected $primaryKey = "id";//tiene que hacer referencia a la llave primaria  
}
