<?php

namespace App\Models\AsignaturaModel;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AsigTecnicos extends Model
{
    protected $table = 'asignaturas_tecnicos';
    protected $primaryKey = "id";
}
