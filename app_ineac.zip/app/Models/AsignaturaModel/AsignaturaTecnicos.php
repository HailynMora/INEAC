<?php

namespace App\Models\AsignaturaModel;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AsignaturaTecnicos extends Model
{
    protected $table = 'asig_tecnicos';
    protected $primaryKey = "id";
}
