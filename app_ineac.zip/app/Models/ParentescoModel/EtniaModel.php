<?php

namespace App\Models\ParentescoModel;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EtniaModel extends Model
{
    protected $table = 'etnia';
    protected $primaryKey = "id";//tiene que hacer referencia a la llave primaria 
}
