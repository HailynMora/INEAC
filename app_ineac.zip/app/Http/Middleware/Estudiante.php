<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;

class Estudiante
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)

    {
        $es = DB::table('roles')->where('roles.descripcion', '=', 'Estudiante')->select('roles.id')->first();
        if (auth()->check() && Auth::user()->id_rol==$es->id){
            return $next($request);
            }
        return redirect('dashboard');
        //##############################
    }
}
